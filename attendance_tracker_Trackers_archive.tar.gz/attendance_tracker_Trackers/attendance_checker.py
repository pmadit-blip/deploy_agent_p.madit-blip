# attendance_checker.py
